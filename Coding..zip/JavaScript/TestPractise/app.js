let button=document.querySelector("button");
let para=document.querySelector("#para");
let div=document.createElement("div");
function createUpperPara(){
  let Upara=para.value.toUpperCase();
  console.log(Upara);
  div.innerText=Upara;
  document.body.append(div);
}
button.addEventListener("click",function(event){
    event.preventDefault();
    console.log("clicked");
    createUpperPara();
});