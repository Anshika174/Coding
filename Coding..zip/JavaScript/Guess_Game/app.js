const max=prompt("Hello Players!! \n Give me an integer.");
const random=Math.floor(Math.random()*max)+1;
let guess=prompt("Guess the random integer");
while(true){
    if(guess=="quit"){
        break;
        console.log("You quit");
    }
    if(random==guess){
        console.log("Guessed right !! the random integer was"+random);
        break;
    }else if(guess<random){
        guess=prompt("Guess was smaller than the random number.Try Again.");
    }else{
    guess=prompt("Guess was larger than the random numnber.Try again.");
    }
    
}