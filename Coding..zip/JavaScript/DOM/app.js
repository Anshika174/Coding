let newIp=document.createElement('input');
let button=document.createElement('button');
button.innerText="Click me!";
button.classList.add("red");
newIp.type="text";
button.classList.add("blue");
document.querySelector("body").append(newIp);
document.querySelector("body").append(button);

newIp.getAttribute('placeholder');
newIp.setAttribute('placeholder',"username");
button.getAttribute('id');
button.setAttribute('id',"btn");

document.querySelector("btn");
btn.classList.add("white");

let h1=document.createElement('h1');
h1.innerText="DOM Practise";
h1.classList.add("purple");
document.querySelector("body").append(h1);

let p=document.createElement('p');
p.innerHTML="Apna College <b>Delta</b> Practise";
document.querySelector("body").append(p);













/*document;
let h3=document.createElement('h3');
h3.innerText="I am a blue h3!";
document.querySelector("body").append(h3);
h3.classList.add("blue");
let div=document.createElement('div');
document.querySelector("body").append(div);
div.classList.add("bp");
let h1=document.createElement('h1');
h1.innerHTML="I am a div!";
div.appendChild(h1);
let para=document.createElement('p');
para.innerHTML="ME TOO!";
div.appendChild(para);*/





