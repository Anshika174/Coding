let div=document.querySelector("div");
let ul=document.querySelector("ul");
let li=document.querySelector("li");


/*event.stopPropagation(); is used to stop event bubbling 
for nested elements*/
div.addEventListener("click",function(event){
    event.stopPropagation();
    console.log("div is clickded");
});
ul.addEventListener("click",function(event){
    event.stopPropagation();
    console.log("ul is clickded");
});
li.addEventListener("click",function(event){
    event.stopPropagation();
    console.log("li is clickded");
});