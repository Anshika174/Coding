let button=document.querySelector("button");
let url="https://dog.ceo/api/breeds/image/random";

button.addEventListener("click",async ()=>{
    let link=await getDog();
    console.log(link);
    let img=document.querySelector("#result");
    img.setAttribute("src",link);

});

async function getDog(){
  try{
  let res=await axios.get(url);
  console.log(res.data.message);
  return res.data.message;
  
  }catch(e){
    console.log("error-",e);
    return "Error Occured";
  }
}