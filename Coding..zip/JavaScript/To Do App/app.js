let input=document.querySelector("input");
let btn=document.querySelector("button");
let ul=document.querySelector("ul");

btn.addEventListener("click",function(){
   let task=document.createElement("li");
   task.innerText=input.value;

   let delbtn=document.createElement("button");
   delbtn.innerText="Delete";
   delbtn.classList.add("delete");

   task.appendChild(delbtn);
   ul.appendChild(task);
   input.value="";//to clean the input after adding it to the list
   });
   //Event Delegation
   ul.addEventListener("click",function(event){
   if(event.target.nodeName=="BUTTON"){
   let listItem=event.target.parentElement;
   listItem.remove();
   console.log("deleted");
   }
   });
 /*let delbtns=document.querySelectorAll(".delete");
 for(delbtn of delbtns){
    delbtn.addEventListener("click",function(){
    let par=this.parentElement;
    console.log(par);
    par.remove();
    });
 }*/
/*let todo=[];
let req=prompt("Hello Nerds!! \n Write your reqest here.");
while(true){
    if(req=="quit"){
        console.log("Quitting the list");
        break;
    }
    if(req=="list"){
        console.log("~~~~~~~~~~~~");
        for(let i=1;i<todo.length;i++){
            console.log(`${i}.${todo[i]}`);
        }
        console.log("~~~~~~~~~~~~");
    }
    else if(req=="add"){
        let toAdd=prompt("Write the task to add.");
        todo.push(toAdd);
        console.log("Task is added to the list");
    }
    else if(req=="delete"){
        let idx=prompt("Write the index of task to delete.");
        todo.splice(idx,1);
        console.log("Task is deleted.");
    }
    else{
        console.log("Oops!Wrong request.");
    }
   req=prompt("Write your request.");
}*/