/* Problem 1
let arr=[1,2,3,4,5];
let arrayAverage=(arr)=>{
    let n=arr.length;
    let sum=0;
 for(let i=0;i<n;i++){
  sum+=arr[i];
 }
 let avg=sum/n;
 return avg;
};
arrayAverage(arr);
*/
/*
problem 2
let isEven=(n)=>{
    if(n%2==0){
    return true;
    }
return false;
}
console.log(isEven(8));
*/