/*Problem 1*/
/*let nums=[1,2,3,4,5];
const square=nums.map((num)=>num*num);
console.log(square);
let sum=square.reduce((acc,cur)=>acc+cur,0);
let avg=sum/nums.length;
console.log(avg);*/

/*Problem 2 */
/*let arr=[1,2,3,4,5];
let arr2=arr.map((number)=>number+5);*/
/*Problem 3*/
/*let orgArray=['car','apple','blue'];
console.log(orgArray.map((word)=>word.toUpperCase()));*/
/*Problem 4*/

