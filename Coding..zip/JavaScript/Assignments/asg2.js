// Q1
// // let num=345;
// if(num %10===0){
//     console.log("good");
// }
// else{
//     console.log("bad");
// }

//Q2
// let firstName=prompt("Enter name:");
// let age=prompt("Enter age:");
// let msg=firstName +" is "+ age+" years old.";
// alert(msg);

// Q3
// let quarter=3;
// switch(quarter){
//     case 1:
//     console.log("Months in Quarter :J,F,M");
//     break;
//     case 2:
//     console.log("Months in Quarter :A,M,J");
//     break;
//     case 3:
//     console.log("Months in Quarter :J,A,S");
//     break;
//     case 4:
//     console.log("Months in Quarter :O,N,D");
//     break;
// }

//Q4
// let str="ahgijbbi";
// if((str[0]==="A" || str[0]==="a") && str.length>5){
//     console.log("golden string");
// }

//Q5
// let a=4;
// let b=9;
// let c=2;
// if(a>b){
//     if(a>c){
//         console.log("a is greatest");
//     }
//     else{
//         console.log("c is greatest");
//     }
// }
// else{
//     if(b>c){
//         console.log("b is greatest");
//     }
//     else{
//         console.log("c is greatest");
//     }
// }

//Q6
let num1=87;
let num2=77;
if(num1%10==num2%10){
    console.log("same last digit");
}
else{
    console.log("Not same");
}