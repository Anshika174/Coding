let msg="help!";
console.log(msg.trim().toUpperCase());

let str="ApnaCollege";
console.log(str.slice(4).replace('l','t'));

let newStr=str.slice(4).replace('l','t').replace('l','t');
console.log(newStr)