function averageOf3(a,b,c){
    console.log((a+b+c)/3);
}
averageOf3(2,4,6);