console.log("Hello World!");
//Example 1-> Traffic light
// let color="red"
// if(color=="red")
// {
//     console.log("Stop");
// }
// if(color=="yellow")
// {
//     console.log("Slow");
// }
// if(color=="green")
// {
//     console.log("Go");
// }

//Practise 
// let size="L";
// let price;
// if(size==="XL"){
//     price=250;
//     console.log(price);
// }
// else if(size==="L"){
//     price=200;
//     console.log(price);
// }
// else if(size==="M"){
//     price=150;
//     console.log(price);
// }
// else if(size==="S"){
//     price=100;
//     console.log(price);
// }
// else{
//     console.log("Try another item.");
// }
//truthy and falsy
// let str="ibcdef";
// if(str[0]="a" && str.length>3){
//     console.log("Good String");
// }
let day=4;
switch(day){
    case 1:
        console.log("Monday");
        break;
    case 2:
        console.log("TUesday");
        break;
    case 3:
        console.log("Wednesday");
        break;
    case 4:
        console.log("Thursday");
        break;

}
