let fName = prompt("Enter your name");
let msg="Welcome to JavaScript "+fName;
alert(msg);