/*let array=[7,9,0,-2];
let n=3;
console.log(array.slice(0,3));

let nums=[7,9,0,-2];
console.log(nums.slice(nums.length-n));

let str=prompt("Please write a string");
if(str.length==0){
    console.log("String is Empty");
}
else{
    console.log("String is not Empty");
}

let str1="abcDEf";
let str2=str1.toLowerCase();
let N=2;
if(str1[N]==str2[N]){
    console.log("Given character is Lower Case");
}
else{
    console.log("not lower");
}

let str="   hello   ";
console.log(str.trim());*/

let arr=[1,2,3,4,5];
let result=arr.includes(7);
if(result==true){
    console.log("present in the array");
}
else{
    console.log("not present in the array");
}


