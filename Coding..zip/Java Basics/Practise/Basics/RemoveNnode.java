public class RemoveNnode {
    static class Node{
        int data;
        Node next;
        public Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    public static Node head;
    public static int removeNfromEnd(Node head,int N){
        Node ref_pointer=head;
        Node main_pointer=head;
        for(int i=0;i<N;i++){
            ref_pointer=ref_pointer.next;
            if(ref_pointer==null){
                return -1;
            }
        }
        while(ref_pointer.next!=null){
            ref_pointer=ref_pointer.next;
            main_pointer=main_pointer.next;
        }
        
        return main_pointer.data;
    }
    public static void printll(Node head){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data);
            if(temp.next!=null){
                System.out.print("->");
            }

        temp=temp.next;
        }
    }

    public static void main(String[] args){
    Node head=new Node(1);
    head.next=new Node(2);
    head.next.next=new Node(3);
    head.next.next.next=new Node(4);
    head.next.next.next.next=new Node(5);

    System.out.print("Original Linked List : ");
    printll(head);
    System.out.println();
    int removed=removeNfromEnd(head, 2);
    System.out.print(removed);
    }
}
