public class ZigZag {
    static class Node{
        int data;
        Node next;
        public Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    public static Node head;
    public static Node middle(Node head){
        Node slow=head;
        Node fast=head;
        while(fast!=null && fast.next!=null){
            slow=slow.next;
            fast=fast.next.next;
        }
        return slow;
    }
    public static Node reverse(Node head){
        Node prev=null;
        Node curr=head;
        Node next;
        while(curr!=null){
            next=curr.next;
            curr.next=prev;
            prev=curr;
            curr=next;
        }
        return prev;

    }
    public static Node zigZag(Node head){
        Node lh=head;
        //step 1 - find mid node
    Node mid=middle(head);
        //step 2 - reverse 2nd half
    Node rh=reverse(mid);
        //step 3 - alternate merge
        Node nextLeft;
        Node nextRight;
        while(lh!=null && rh!=null){
            nextLeft=lh.next;
            lh.next=rh;
            nextRight=rh.next;
            rh.next=nextLeft;
            lh=nextLeft;
            rh=nextRight;
        }
        return head;

        
    }
    public static void printll(Node head){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data);
            if(temp.next!=null){
                System.out.print("->");
            }

        temp=temp.next;
        }
    }
    public static void main(String[] args){
     Node head=new Node(1);
    head.next=new Node(2);
    head.next.next=new Node(3);
    head.next.next.next=new Node(4);
    head.next.next.next.next=new Node(5);
    System.out.print("Original Linked List : ");
    printll(head);
    System.out.println();
    Node result=zigZag(head);
    System.out.print("Zig Zag Linked List : ");
    printll(result);
    }
}
