import java.util.*;
public class Count_Digits{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int x=num;
        int count=0;
        int n;
        while(x>0){
            n=x%10;
            count++;
            x=x/10;
        }
        System.out.print("Digits in number:"+count);
    }
}
