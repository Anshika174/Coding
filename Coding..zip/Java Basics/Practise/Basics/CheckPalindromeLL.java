public class CheckPalindromeLL {
    static class Node{
        int data;
        Node next;
        public Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    public static Node head;
    public static Node middle(Node head){
        Node slow=head;
        Node fast=head;
        while(fast!=null && fast.next!=null){
            slow=slow.next;
            fast=fast.next.next;
        }
        return slow;
    }
    public static Node reverse(Node head){
        Node prev=null;
        Node curr=head;
        Node next;
        while(curr!=null){
            next=curr.next;
            curr.next=prev;
            prev=curr;
            curr=next;
        }
        return prev;

    }
    public static boolean isPalindrome(Node head){
        Node head1=head;
        //step 1 - find mid node
    Node mid=middle(head);
        //step 2 - reverse 2nd half
    Node head2=reverse(mid);
        //step 3 - check if same 
        Node temp1=head1;
        Node temp2=head2;
        while(temp1!=null && temp2!=null){
            if(temp1.data!=temp2.data){
                return false;
            }
                temp1=temp1.next;
                temp2=temp2.next;
        }
        return true;
    }
    public static void printll(Node head){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data);
            if(temp.next!=null){
                System.out.print("->");
            }

        temp=temp.next;
        }
    }
    public static void main(String[] args){
     Node head=new Node(1);
    head.next=new Node(2);
    head.next.next=new Node(2);
    head.next.next.next=new Node(2);
    head.next.next.next.next=new Node(1);
    System.out.print("Original Linked List : ");
    printll(head);
    System.out.println();
    System.out.print("Is Linked List Palindrome ? - "+isPalindrome(head));
    }
}
