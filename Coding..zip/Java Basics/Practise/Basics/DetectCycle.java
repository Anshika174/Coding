public class DetectCycle {
    static class Node{
        int data;
        Node next;
        public Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    public static Node head;

    public static boolean hasCycle(Node head){
        if(head==null || head.next==null){
            return false;
        }
        Node slow=head;
        Node fast=head;

        while(fast!=null && fast.next!=null){
            slow.next=slow;
            fast.next.next=fast;

            if(slow==fast){
                return true;
            }
        }
        return false;
    }
    public static void printll(Node head){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data);
            if(temp.next!=null){
                System.out.print("->");
            }

        temp=temp.next;
        }
    }
    public static void main(String[] args){
    Node head=new Node(1);
    head.next=new Node(2);
    head.next.next=new Node(3);
    head.next.next.next=new Node(4);
    head.next.next.next.next=new Node(5);
    head.next.next.next.next.next=head.next;

    if(hasCycle(head)==true){
    System.out.print("Cycle detected");
    }
    else{
       System.out.print("Cycle is not detected"); 
    }
    }
}

