package Test;
import java.util.*;
public class test2 {

    /*PROBLEM NO. ->1
    public static int findFirst(int []arr,int target){
    int low=0,high=arr.length-1,result=-1;
    while(low<=high){
        int mid=low+(high-low)/2;
        if(arr[mid]==target){
            result=mid;
            high=mid-1;
        }
        else if(arr[mid]<target){
            low=mid+1;
        }
        else{
            high=mid-1;
        }
    }
    return result;

    }
    public static int findLast(int []arr,int target){
        int low=0,high=arr.length-1,result=-1;
        while(low<=high){
            int mid=low+(high-low)/2;
            if(arr[mid]==target){
                result=mid;
                low=mid+1;
            }
            else if(arr[mid]<target){
                low=mid+1;
            }
            else{
                high=mid-1;
            }
        }
        return result;
    
        }
        public static void main(String []args){
            Scanner sc=new Scanner(System.in);
            String input=sc.nextLine();
            String[] inputArray=input.split(" ");
            int [] arr=new int[inputArray.length];
            for(int i=0;i<inputArray.length;i++){
                arr[i]=Integer.parseInt(inputArray[i]);
            }
            Arrays.sort(arr);
            int target=sc.nextInt();
            int first=findFirst(arr, target);
            int last=findLast(arr,target);
            System.out.print(first+" ");
            System.out.print(last);
        }*/
    /*PROBLEM NO. ->2 */

    /*public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        ArrayList<Integer> arr=new ArrayList<>();
        for(int i=0;i<n;i++){
            arr.add(sc.nextInt());
        }
        int X=sc.nextInt();
        int D=sc.nextInt();
        int S=sc.nextInt();
        insert(arr, X);
        arr.remove((Integer)D);
        System.out.print("Updated Array : ");
        for(int i=0;i<arr.size();i++){
            
            System.out.print(arr.get(i)+" ");
        }
        System.out.println();
        int result=Search(arr, S);
        if(result!=-1){
        System.out.println("Ememnt found at :"+result);
        }
        else{
            System.out.println("Ememnt is not found ");
        }


    }
    public static int Search(ArrayList<Integer> arr,int target){
    int low=0,high=arr.size()-1,result=-1;
        while(low<=high){
        int mid=low+(high-low)/2;
        if(arr.get(mid)==target){
            result=mid;
            break;
        }
        else if(arr.get(mid)<target){
            low=mid+1;
        }
        else{
            high=mid-1;
        }
        }
        return result;
    }
    public static void insert(ArrayList<Integer> arr,int X){
        int i=0;
        int N=arr.size();
    while(i<N && arr.get(i)<X){
        i++;
    }
    arr.add(i,X);
    }*/
    /*PROBLEM NO. 3*/
    /*public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sc.nextLine();
        String str=sc.nextLine();
        if(str.length()!=n){
            System.out.println("N is not matched to string length");
            return;
        }
        StringBuilder line=new StringBuilder();
        line.append(str.charAt(0));
        for(int i=1;i<str.length();i++){
          char prev=Character.toLowerCase(str.charAt(i-1));
          char curr=Character.toLowerCase(str.charAt(i));
          if(curr==prev+1){
            line.append(str.charAt(i));
          }
          else{
            System.out.println(line);
            line.setLength(0);
            line.append(str.charAt(i));
          }
        }
        if(line.length()>0){
            System.out.println(line);
        }
        sc.close();
    }*/
    /*PROBLEM NO.4*/
    /*public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        List<String> words=new ArrayList<>();
        
        while(sc.hasNextLine()){
        String line=sc.nextLine().trim();
        if (line.equalsIgnoreCase("END")) break; //to break the input cycle and the input are done taking
        if(!line.isEmpty()){
            words.add(line);
        }
        }
        words.sort(Comparator.comparingInt(String::length));
        //str->str.length is also same for String::length
        for(String word:words){
            System.out.print(word+" ");
        }
        sc.close();
    }*/
}
