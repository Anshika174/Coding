package Test;
/*import java.util.*;
public class test1 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int raindrop[]=new int[12];
        for(int i=0;i<12;i++){
            raindrop[i]=sc.nextInt();
        }
        int sum=0,max=raindrop[0],min=raindrop[0];
        int maxMonth=1,minMonth=1;
        for(int i=0;i<12;i++){
            sum+=raindrop[i];
            if(raindrop[i]<min){
                min=raindrop[i];
                minMonth=i+1;
            }
            if(raindrop[i]>max){
                max=raindrop[i];
                maxMonth=i+1;

            }
        }
            double avg=(double)sum/12;
            System.out.println("Sum"+sum);
            System.out.println("Avg"+String.format("%.2f",avg));
            System.out.println("Maximum"+max);
            System.out.println("Minimum"+min);
        


    }*/
    
        /*public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            int n=sc.nextInt();
            
            int number[]=new int[n];
            for(int i=0;i<n;i++){
                number[i]=sc.nextInt();
            }
            int k=sc.nextInt();
            int grcounter=0,lscounter=0;
            int divisiblecounter=0;
            for(int num:number){
                if(num>k){
                    grcounter++;
                }
                if(num<k){
                    lscounter++;
                }
                if(num%k==0){
                    divisiblecounter++;
                }
            }
            System.out.println("Greater than k:"+grcounter);
            System.out.println("Lesser than k:"+lscounter);
            System.out.println("Divisible by k:"+divisiblecounter);
        }*/
    /*public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        String input=sc.nextLine();
        int sum=0;
        String temp="";
        for(int i=0;i<input.length();i++){
        char ch=input.charAt(i);
        if(Character.isDigit(ch)){
            temp+=ch;
        }
        else{
            if(!temp.isEmpty()){
                sum+=Integer.parseInt(temp);
                temp="";
            }
        }
        }
        if(!temp.isEmpty()){
            sum+=Integer.parseInt(temp);
            temp="";
        }
        System.out.println("Sum: "+sum);
        sc.close();

    }*/
    /*public static int longestPalLength(String s1,String s2){
        HashMap<Character,Integer> freqMap=new HashMap<>();
        String combined=s1+s2;
        for(char ch:combined.toCharArray()){
            freqMap.put(ch,freqMap.getOrDefault(ch,0)+1);
        }
        int length=0;
        boolean hasOdd=false;
        for(int freq:freqMap.values()){
            length+=(freq/2)*2;
            if(freq%2==1){
                hasOdd=true;
            }
            
        }
        if(hasOdd){
            length++;
        }
        return length;
    }
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        String s2=sc.nextLine();
        int palLength=longestPalLength(s1, s2);
        System.out.println(palLength);
    }
        */
    

