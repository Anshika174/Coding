public class reverse_array {
    public static void reversearray(int array[]){
    int first=0;
    int last =array.length-1;
    while(first<last){
        int temp=array[last];
        array[last]=array[first];
        array[first]=temp;

        first++;
        last--;
    }
    } 
    public static void main(String args[]){
        int array[]={8,9,0,4,6,7,8,5,3};
        reversearray(array);
        System.out.println("Reverse array :");
        for(int i=0;i<=array.length-1;i++){
            System.out.println(array[i]);
        }
        System.out.println();
    }
}
