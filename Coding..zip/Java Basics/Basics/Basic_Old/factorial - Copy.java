
import java.util.*;
public class factorial{
    public static int fact(int n){
        int f=1;
        for(int i=1;i<=n;i++){
            f=f*i;
        }
        return f;
        }
    public static int bionomialcoef(int n,int r){
       int n_facto=fact(n);
       int r_facto=fact(r);
       int nmr_facto=fact(n-r);
       int bc= n_facto/(r_facto*nmr_facto);
       return bc;
    }
    public static void main(String args[]){
        System.out.print(bionomialcoef(7,0));
    }
}
   


    

