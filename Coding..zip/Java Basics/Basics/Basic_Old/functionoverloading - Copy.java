public class functionoverloading {
    public static int mul(int a,int b){
        return a*b;
    }
    public static int mul(int a,int b,int c){
        return a*b*c;
    }
    public static void main(String args[]){
        System.out.println(mul(3,5));
        System.out.println(mul(6,4,3));
    }
}
