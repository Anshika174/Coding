public class reversearray {
    public static int reverse(int arr[]){
        int front=0;
        int last=arr.length-1;
        for()

    }
    
}
