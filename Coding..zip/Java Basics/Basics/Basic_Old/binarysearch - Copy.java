 public class binarysearch {
    public static int binary_search(int arr[],int key){
       int s=0; 
       int e=arr.length-1;
       while(s<=e){
        int mid=(s+e)/2;
        if(arr[mid]==key){
            return mid;
        }
        if(arr[mid]>key){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        }
    return -1;

        
    }
    public static void main(String args[]){
        int arr[]={78,98,101,103,177};
        int key=103;
        System.out.println("Item found at "+binary_search(arr,key));
    }
}
    

