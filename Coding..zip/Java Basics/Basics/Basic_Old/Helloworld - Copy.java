import java.util.*;
class Helloworld{
    public static void main(String args[]){
      System.out.println("Welcome to Java Calculator");
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the value of a");
      double a=sc.nextDouble();
      System.out.println("Enter the value of b");
      double b=sc.nextDouble();
      System.out.println("Enter the value of operator(+,-,*,/):");
      char op=sc.next().charAt(0);
      double c=0;
      switch(op){
        case '+':c=a+b;
                 break;
        case '-':c=a-b;
                 break;
        case '*':c=a*b;
                 break;
        case '/':c=a/b;
                 break;
        default:
                System.out.println("Choose a valid choice.");
      }
      System.out.println("The result is "+c);
    }

}
    
