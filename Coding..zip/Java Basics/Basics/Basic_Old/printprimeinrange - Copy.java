import java.util.*;
public class printprimeinrange {
    public static boolean isPrime(int n){
        for (int i=3;i<=n;i++){
            if(n%2==0)
            return false;
        }
        return true;
        }
        public static void main (String args[]){
            
            Scanner sc=new Scanner(System.in);
            int num=sc.nextInt();
            System.out.print("prime no. till number are");
               for(int n=2;n<=num;n++)
            {boolean flag=isPrime(n);
                if(flag==true)
               System.out.println(n);  
            }
        }
    }
