public class maxsubarraysumprefix {
    public static void maxSubarraysum(int array[]){
        int maxsum=Integer.MIN_VALUE;
        int currSum=0;
        int[] prefix=new int[array.length];
        prefix[0]=array[0];
        for(int i=1;i<array.length;i++){
            prefix[i]=prefix[i-1]+array[i];
        }
        for(int i=0;i<array.length;i++){
             int start=i;
            for(int j=i;j<array.length;j++){
                int end=j;
                currSum=start==0?prefix[end]:prefix[end]-prefix[start-1];
                if(maxsum<currSum){
                    maxsum=currSum;
                }
            }
        }
        for(int i=0;i<array.length;i++){
            System.out.print(prefix[i]+" ");
        }
        System.out.println();
        System.out.print("Max Sum = "+maxsum);
    }
    public static void main(String args[]){
        int array[]={3,-1,4,6,2,-3};
        maxSubarraysum(array);
            
    
    
    }
        
}