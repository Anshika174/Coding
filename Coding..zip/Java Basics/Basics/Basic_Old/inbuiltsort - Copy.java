import java.util.Arrays;
import java.util.Collections;
public class inbuiltsort{
    public static void sort(Integer arr[]){
        Arrays.sort(arr,Collections.reverseOrder());
    }
    public static void main(String args[]){
        Integer arr[]={3,7,6,8,4,9,1};
        sort(arr);
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
