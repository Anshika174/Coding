public class nQueens {
    //all ways
    public static void main(String args[]){
        
    }
}
