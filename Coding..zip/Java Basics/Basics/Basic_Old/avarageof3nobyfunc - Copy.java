import java.util.*;
public class avarageof3nobyfunc {
    public static float average(int a,int b,int c){
         float avg;
         avg=(float)(a+b+c)/3;
         return avg;    
    }
    public static void main(String arg[]){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        float avr=average(a,b,c);
        System.out.println("average of "+a+","+b+" and "+c+" is " +avr);

    }
    
}
