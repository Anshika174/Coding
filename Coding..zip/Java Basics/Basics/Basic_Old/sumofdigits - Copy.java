import java.util.*;
public class sumofdigits {
    public static int sumofdigit(int n){
        int d;
        int sum=0;
        while(n!=0){
            d=n%10;
            sum=sum+d;
            n=n/10;
        }
        System.out.println("sum of digits of a integer:"+sum);
        return sum;
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sumofdigit(n);

    }
    
}
