import java.util.*;
public class revision {
    public static void maxSubarraysum(int[] array){
        int currSum=0;
        int maxSum=Integer.MIN_VALUE;
        for(int i=0;i<array.length;i++){
            int start=i;
            for(int j=i;j<array.length;j++){
                int end=j;
                currSum=0;
                for(int k=start;k<=end;k++){
                    currSum+=array[k];
                    

                }
                System.out.print(currSum);
                
                if(maxSum<currSum){
                    maxSum=currSum;
                }
                System.out.println();
            }
        }
        
        System.out.print("Maximum Subarray Sum: "+maxSum);
    }
    public static void main(String args[]){
        int array[]={1,2,3,4,5};
        maxSubarraysum(array);
        
        
        
    }
}


        
