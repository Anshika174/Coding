public class binarytodecimal {
    public static int btod(int n){
        int ld,sum=0;
        int pow=0;
        while(n>0)
        {ld=n%10;
        sum=sum+(ld*(int)Math.pow(2,pow));
        pow++;
        n=n/10;
        }
        return sum;
    }
        public static void main(String args[]){
        int btd=btod(1101);
        System.out.println("Binary to Decimal of given number:"+btd);
        }

        
    public static void dtob(int n){
        int rem=0;
        int num=n;
        int binary=0;
        int pow=0;
        while(n>0){
            rem=n%2;
            binary=binary+(rem*(int)Math.pow(10,pow));
            pow++;
            n=n/2;
        } 
        System.out.print("decimal " + num + " to binary " + binary);
    } 
    public static void main(String args[]){
        dtob(11);
    }
}
