public class linearsearch{
    public static int linear_search(int arr[],int item){
        
        for(int i=0;i<=arr.length;i++){
            if(arr[i]==item){
               return i;
            }
        }
            
        return -1;
            
        
    }
    public static void main(String srgs[]){
        int arr[]={7,8,3,65,94};
        int item =8;
        int index=  linear_search(arr,item);
        if(index==-1){
            System.out.print("Not found");
        }
        else{
            System.out.print("found at index "+index);
        }


    }
}