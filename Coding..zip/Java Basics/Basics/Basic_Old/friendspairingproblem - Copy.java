public class friendspairingproblem {
    public static int friendspairing(int n){
        if(n==1||n==2){
            return n;
        }
        return friendspairing(n-1)+(n-1)*friendspairing(n-2);
        //if choice is single=f(n-1)
        //if choice is pair =(n-1)*f(n-2)
    }
    public static void main(String args[]){
        friendspairing(5)  ;
        System.out.print(friendspairing(5));
    }
}
