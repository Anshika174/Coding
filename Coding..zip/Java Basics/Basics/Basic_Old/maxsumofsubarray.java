import java.util.*;
public class maxsumofsubarray{
    public static void number(int n[]){
        int maxsum=Integer.MIN_VALUE;
        int currsum=0;
        for(int i=0;i<n.length;i++){
                int start=i;
                for(int j=i;j<n.length;j++){
                int end=j;
                currsum=0;

                    for(int k=start;k<=end;k++){
                         currsum+=n[k];
                        
                    }
                        System.out.print(currsum);
                        if(maxsum<currsum){
                            maxsum=currsum;
                        }
                    System.out.println();
                }

        }
        System.out.print("maximum sum ="+maxsum);
    }
    public static void main(String args[]){
        int n[]={1,-2,6,-1,3};
        number(n);

    }
}
