public class Rfibonacci {
    public static int fibo(int n){
        if(n==0){
            return 0;
        }
        if(n==1){
            return 1;
        }
        int fibonm1=fibo(n-1);
        int fibonm2=fibo(n-2);
        int fibon=fibo(n-1)+fibo(n-2);
        return fibon;
    }
    public static void main(String args[]){
      fibo(5);
      System.out.print(fibo(5));
    }
    
}
