public class hello {
    public static void main(String args[]){
        System.out.println("Anshika Chaudhary");
        System.out.println("2201920100348");
        System.out.println("Hello World!");

    }
    
}
