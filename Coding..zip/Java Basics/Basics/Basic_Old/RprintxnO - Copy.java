public class RprintxnO {
    public static int optimized_printxn(int x,int n){
        if(n==0){
            return 1;
        }
        int halfpow=optimized_printxn(x,n/2);
        int halfsquare=halfpow*halfpow;
        if(n%2!=0){
            return x*halfsquare; 
        }
        return halfsquare;

    }
    public static void main(String args[]){
        optimized_printxn(2,8) ;
        System.out.print(optimized_printxn(2,8));  
    }
    
}
