import java.util.*;
public class Rpowxn {
    public static double powxn(double x,double n){
        if(n==1){
            return x;
        }
        
        double powx_n=x*Math.pow(x,n-1);
        return powx_n;

    }
    public static void main(String args[]){
     powxn(3,5);
     System.out.print(powxn(3,5));
    }
}
