public class printsubarray {
    public static void print_subarray(int nu[]){
        int total=0;
        int sum=0;
        int largest=Integer.MIN_VALUE;
        int smallest=Integer.MAX_VALUE;
        for(int i=0;i<nu.length;i++){
            int start=i;
            for(int j=i;j<nu.length;j++){
                int end=j;
                for(int k=start;k<=end;k++){
                    
                    System.out.print(nu[k]+" ");
                    
                    total++;
                }
            sum=sum+nu[end];
            System.out.print("Sum :"+sum);
            System.out.println();
            for(int x=start;x<=end;x++){
                if(sum>largest){
                   largest=sum;
                }   
                if(sum<smallest){
                   smallest=sum;
                }
            }
            }
        
    
        
              System.out.println();
        }
    
        System.out.println("TOATAL PAIRS : "+total);
        System.out.println(largest);
        System.out.println(smallest);

    }
        
        
    
    public static void main(String args[]){
        int nu[]={4,7,8,6,9,2};
        print_subarray(nu);
        


    }
    
}
