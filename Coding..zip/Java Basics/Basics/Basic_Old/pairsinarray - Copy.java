public class pairsinarray {
    public static void pairs(int po[]){
        int i;
        int j;
        int total=0;
        for(i=0;i<po.length;i++){
            int current=po[i];
            for( j=i+1;j<po.length;j++){
                System.out.print("("+current+","+po[j]+")");
                total++;
            }
            System.out.println();
        }
        System.out.println("total pairs: "+total);
    }
    public static void main(String args[]){
        int po[]={5,7,3,9,8,6};
        pairs(po);
    }
}

