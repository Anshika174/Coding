public class maxsubarraysumkadans {
    public static void maxSubarraysum(int array[]){
        int maxsum=Integer.MIN_VALUE;
        int currSum=0;
        for(int i=0;i<array.length;i++){
            currSum=currSum+array[i];
            if(currSum<0){
                currSum=0;
            }
            maxsum=Math.max(currSum,maxsum);
        }
        System.out.print("MaxSum : "+maxsum);
    }
    public static void main(String args[]){
        int array[]={-2,-3,4,-1,-2,1,5,-3};
        maxSubarraysum(array);
    }
            
}

