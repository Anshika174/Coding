public class bubblesort{
    public static void bubble_sort(int number[]){
        for(int i=0;i<=number.length-2;i++){
            for(int j=0;j<=number.length-2;j++){
                if(number[j]>number[j+1]){
                    int temp=number[j+1];
                    number[j+1]=number[j];
                    number[j]=temp;
                }
            }
        }
    }
    public static void main (String args[]){
        int number[]={7,8,5,9,3,4,1};
        bubble_sort(number);
        for(int i=0;i<number.length;i++){
            System.out.print(number[i]+" ");
        }
    }
}