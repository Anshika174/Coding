public class Recursionp2hw1 {
    public static void printIndex(int arr[],int key,int i){
       if(i==arr.length){
    return;
        }
       if(arr[i]==key){
        System.out.print(i+" ");
       
       }
       printIndex(arr, key,i+1);
       
    }
    public static void main(String args[]){
        int arr[]=new int[]{5,3,7,3,9,3,4,5,3,8};
       printIndex(arr, 3, 0);
        System.out.println();    
    }
    
}
