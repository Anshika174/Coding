public class Recursionp2hw4 {
    public static void count_substring(char[] arr,String string,String newstr,int i,int n){
        if(string.isEmpty()){
            return;
        }
        if(newstr.charAt(0)==newstr.charAt(newstr.length()-1)){
            return;
        }
        count_substring(arr, string.substring(1), newstr, i+1, n+1);


    }
    public static void main(String args[]){
        String string="abcab";
        char[] arr=string.toCharArray();
        String newstr=new String(arr);
        count_substring(arr, string, newstr, 0, 0);

    }
}
