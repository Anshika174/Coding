public class tilingproblem {
    public static int tilingproblem(int n){
        //Base Case
        if(n==0||n==1){
            return 1;
        }
        //kaam
        //vertical choice
        int fnm1=tilingproblem(n-1);
        //horizontal choice
        int fnm2=tilingproblem(n-2);
        int totalways=fnm1+fnm2;
        return totalways;
        
    }
    public static void main(String args[]){
        tilingproblem(10);
        System.out.println(tilingproblem(10));
    }
    
}
