import java.util.*;
public class RsumofFactorialtilln {
    static ArrayList<Long> factorialNumberHelper(long N,long i,long fact,ArrayList<Long> result){
        if(fact>N){
            return result;
        }
        result.add(fact);
        return factorialNumberHelper(N,i+1,fact*(i+1),result);
    }
    static ArrayList<Long> factorialNumber(long N){
        ArrayList<Long> result=new ArrayList<>();
        return factorialNumberHelper(N,1,1,result);
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        long N=sc.nextLong();
        System.out.print(factorialNumber(N));
    }
    
}
