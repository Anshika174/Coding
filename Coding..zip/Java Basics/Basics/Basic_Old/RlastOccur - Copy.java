public class RlastOccur{
    public static int lastOccur(int arr[],int key,int i){
        if(i==arr.length){
            return -1;
        }
        int isFound=lastOccur(arr,key,i+1);
        if(isFound==-1 && arr[i]==key){
            return i;
        }
        return isFound;

    }
    public static void main(String args[]){
        
       int arr[]={2,5,4,6,2,7,2,2};
       lastOccur(arr,2,0);
       System.out.print(lastOccur(arr,2,0));
    }
}