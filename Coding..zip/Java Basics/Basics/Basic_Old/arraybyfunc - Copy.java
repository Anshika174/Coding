public class arraybyfunc {
    public static void update(int marks[]){
        for(int i=0;i<marks.length;i++){
            marks[i]=2*marks[i];
        }
    }
    public static void main(String args[]){
        int marks[]={89,90,99};
        update(marks);
        for(int i=0;i<marks.length;i++){
            System.out.println(marks[i]);
        } 
    }
    
}
