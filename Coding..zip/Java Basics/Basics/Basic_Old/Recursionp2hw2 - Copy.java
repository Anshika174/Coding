public class Recursionp2hw2 {
    public static  String digits[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
    public static void binarytoString(int num){
        if(num==0){
            return;
        }
        int lastdigits=num%10;
        binarytoString(num/10);
        System.out.print(digits[lastdigits]+" ");
    }
    public static void main(String args[]){
        binarytoString(5463);
        System.out.println();  
    }
}

   
    
    


    

