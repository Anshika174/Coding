public class Recursionp2hw3 {
    
    public static void lengthofString(String str,char arr[],int i){
        if(i==arr.length){
           System.out.print(i);
           return;
         }
         lengthofString(str,arr,i+1);
    }
    
    public static void main(String args[]){
        String str="hello";
        char[] arr=str.toCharArray();
        lengthofString(str,arr,0);
       
         
         

    }
    
}
