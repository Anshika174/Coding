public class CountDigits {
        public static int count(int n) {
            if (n == 0) return 0;
            return 1 + count(n / 10);
        }
    
        public static void main(String[] args) {
            int number = 12345;
            System.out.println("Number of digits: " + count(number));
        }
}
    

