public class PalindromeCheck {
    public static boolean isPalindrome(String str, int start, int end) {
        if (start >= end) return true; // our base case — the heart of symmetry
        if (str.charAt(start) != str.charAt(end)) return false; // if they don’t match, love is lost 💔
        return isPalindrome(str, start + 1, end - 1); // like a waltz, moving inward together
    }

    public static void main(String[] args) {
        String word = "caroline";
        System.out.println(isPalindrome(word, 0, word.length() - 1)); // true
    }
}
