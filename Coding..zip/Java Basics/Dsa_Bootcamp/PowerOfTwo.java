public class PowerOfTwo {
    public static int power(int n) {
        if (n == 0) return 1;
        return 2 * power(n - 1);
    }

    public static void main(String[] args) {
        int exponent = 5;
        System.out.println("2^" + exponent + " = " + power(exponent));
    }
}

