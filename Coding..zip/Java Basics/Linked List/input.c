int main() {
    int a = 10;
    float b = 20.5;
    if (a > b) {
        return 0;
    }
}
